import 'dart:io';
import 'dart:math';
import 'dart:ui' as ui;
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'comic.dart';
import 'engine.dart';
import 'gutter.dart';
import 'models.dart';

const orange = Color(0xFFFF6B3D);
const grey = TextStyle(color: Color(0xFF8D8D8D), fontSize: 13);

void main() => runApp(const App());

class App extends StatefulWidget {
  const App({super.key});
  @override
  State<App> createState() => _AppState();
}

class _AppState extends State<App> {
  ThemeMode mode = ThemeMode.dark;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<File> _file() async {
    final d = await getApplicationSupportDirectory();
    return File('${d.path}${Platform.pathSeparator}tema.txt');
  }

  Future<void> _load() async {
    try {
      final f = await _file();
      if (!f.existsSync()) return;
      final s = f.readAsStringSync().trim();
      if (!mounted) return;
      setState(() => mode = switch (s) {
            'light' => ThemeMode.light,
            'system' => ThemeMode.system,
            _ => ThemeMode.dark,
          });
    } catch (_) {}
  }

  Future<void> _set(ThemeMode m) async {
    setState(() => mode = m);
    try {
      final f = await _file();
      f.writeAsStringSync(switch (m) {
        ThemeMode.light => 'light',
        ThemeMode.system => 'system',
        _ => 'dark',
      });
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Video Comik Editor',
        debugShowCheckedModeBanner: false,
        themeMode: mode,
        theme: ThemeData(
          brightness: Brightness.light,
          useMaterial3: true,
          colorSchemeSeed: orange,
          scaffoldBackgroundColor: const Color(0xFFF7F4F1),
        ),
        darkTheme: ThemeData(
          brightness: Brightness.dark,
          useMaterial3: true,
          colorSchemeSeed: orange,
          scaffoldBackgroundColor: const Color(0xFF121212),
        ),
        home: Home(mode: mode, onMode: _set),
      );
}

class Home extends StatefulWidget {
  final ThemeMode mode;
  final ValueChanged<ThemeMode> onMode;
  const Home({super.key, required this.mode, required this.onMode});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int step = 0;
  Fmt? fmt;
  final parts = <Part>[Part()];
  final bg = Bg();
  final opts = Opts();
  double thumbSize = 150; // ukuran gambar di daftar foto/video
  int outMode = 0; // 0 = gabung semua part, 1 = per part, 2 = per slide
  double pause = 3; // jeda antar slide (detik)
  bool busy = false;
  String status = '';
  double prog = 0;
  ui.Image? bgImg; // gambar latar yang sudah dibaca (untuk pratinjau)
  int pv = 0; // halaman pratinjau
  int _rev = 0; // memaksa kolom waktu dibuat ulang saat nilai diubah dari luar

  int get totalItems => parts.fold(0, (a, p) => a + p.items.length);

  /// Semua slide dari semua part: (isi slide, nomor slide dalam part, nomor part).
  List<(List<Media>, int, int)> get allPages {
    final out = <(List<Media>, int, int)>[];
    for (var pi = 0; pi < parts.length; pi++) {
      final fr = parts[pi].frames;
      for (var f = 0; f < fr.length; f++) {
        out.add((fr[f], f, pi));
      }
    }
    return out;
  }

  // ---------- aksi ----------
  Future<void> addMedia(Part part) async {
    final r = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: const ['jpg', 'jpeg', 'png', 'webp', 'bmp', 'mp4', 'mov', 'mkv', 'webm', '3gp', 'avi', 'm4v'],
      allowMultiple: true,
    );
    if (r == null) return;
    for (final f in r.files) {
      final p = f.path;
      if (p == null || totalItems >= kMaxItems) continue;
      final v = isVideoPath(p);
      final info = await probeInfo(p);
      final m = Media(p, v, v ? info.dur : 0);
      m.w = info.w;
      m.h = info.h;
      part.items.add(m);
    }
    if (mounted) setState(() => _rev++);
  }

  Future<void> addSound(Part part) async {
    final r = await FilePicker.platform.pickFiles(type: FileType.audio);
    final f = r?.files.single;
    if (f == null || f.path == null) return;
    final len = await probeDuration(f.path!);
    part.sound = Sound(f.path!, f.name, len);
    if (mounted) setState(() => _rev++);
  }

  Future<void> pickBg() async {
    final r = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: const ['jpg', 'jpeg', 'png', 'webp', 'bmp', 'gif'],
    );
    final p = r?.files.single.path;
    if (p == null) return;
    final im = await loadUiImage(p);
    if (!mounted) return;
    if (im == null) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Gambar latar tidak bisa dibaca. Coba format JPG atau PNG.')));
      return;
    }
    setState(() {
      bg.image = p;
      bgImg = im;
    });
  }

  Future<void> _export() async {
    setState(() {
      busy = true;
      status = 'Menyiapkan…';
      prog = 0;
    });
    String msg;
    try {
      final outPath = await renderProject(
        fmt: fmt!,
        parts: parts,
        bg: bg,
        pause: pause,
        outMode: outMode,
        opts: opts,
        onProgress: (m, v) {
          if (mounted) {
            setState(() {
              status = m;
              prog = v;
            });
          }
        },
      );
      final n = outPath.split('\n').length;
      msg = n == 1 ? 'Selesai! Video tersimpan di:\n$outPath' : 'Selesai! $n video tersimpan di:\n$outPath';
    } catch (e) {
      msg = 'Gagal: $e';
    }
    if (!mounted) return;
    setState(() => busy = false);
    showDialog(
      context: context,
      builder: (c) => AlertDialog(
        content: SingleChildScrollView(child: SelectableText(msg)),
        actions: [TextButton(onPressed: () => Navigator.pop(c), child: const Text('OK'))],
      ),
    );
  }

  bool get _canNext => switch (step) { 0 => fmt != null, 1 => totalItems > 0, _ => true };

  void _next() => step < 3 ? setState(() => step++) : _export();

  // ---------- kerangka ----------
  @override
  Widget build(BuildContext context) {
    const titles = ['Pilih Format', 'Part: Audio & Foto/Video', 'Latar & Gaya Frame', 'Ekspor'];
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 8,
        title: Row(children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: Image.asset('assets/logo.png', width: 36, height: 36, cacheWidth: 128, filterQuality: FilterQuality.medium),
          ),
          const SizedBox(width: 10),
          Flexible(child: Text('${step + 1}/4  ${titles[step]}', overflow: TextOverflow.ellipsis)),
        ]),
        actions: [
          PopupMenuButton<ThemeMode>(
            tooltip: 'Tema tampilan',
            icon: Icon(switch (widget.mode) {
              ThemeMode.light => Icons.light_mode,
              ThemeMode.system => Icons.brightness_auto,
              _ => Icons.dark_mode,
            }),
            initialValue: widget.mode,
            onSelected: widget.onMode,
            itemBuilder: (c) => const [
              PopupMenuItem(value: ThemeMode.dark, child: Text('Gelap')),
              PopupMenuItem(value: ThemeMode.light, child: Text('Terang')),
              PopupMenuItem(value: ThemeMode.system, child: Text('Ikuti sistem')),
            ],
          ),
        ],
      ),
      body: busy ? _busy() : _body(),
      bottomNavigationBar: busy
          ? null
          : SafeArea(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Row(children: [
                  if (step > 0) ...[
                    Expanded(child: OutlinedButton(onPressed: () => setState(() => step--), child: const Text('Kembali'))),
                    const SizedBox(width: 12),
                  ],
                  Expanded(
                    flex: 2,
                    child: FilledButton(
                      onPressed: _canNext ? _next : null,
                      child: Text(step == 3 ? 'Ekspor' : 'Lanjut'),
                    ),
                  ),
                ]),
              ),
            ),
    );
  }

  Widget _body() => switch (step) {
        0 => _formatStep(),
        1 => _partsStep(),
        2 => _bgStep(),
        _ => _exportStep(),
      };

  Widget _busy() => Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            LinearProgressIndicator(value: prog),
            const SizedBox(height: 16),
            Text(status),
            const SizedBox(height: 24),
            OutlinedButton(onPressed: cancelRender, child: const Text('Batalkan')),
          ]),
        ),
      );

  // ---------- 1: format ----------
  Widget _formatStep() => Padding(
        padding: const EdgeInsets.all(16),
        child: GridView.count(
          crossAxisCount: 2,
          mainAxisSpacing: 12,
          crossAxisSpacing: 12,
          children: [
            for (final f in formats)
              InkWell(
                onTap: () => setState(() => fmt = f),
                child: Container(
                  decoration: BoxDecoration(
                    color: Theme.of(context).cardColor,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(width: 2, color: fmt == f ? orange : Theme.of(context).dividerColor),
                  ),
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    SizedBox(
                      width: 90,
                      height: 90,
                      child: Center(
                        child: AspectRatio(
                          aspectRatio: f.w / f.h,
                          child: Container(
                            decoration: BoxDecoration(
                              border: Border.all(width: 2, color: fmt == f ? orange : Colors.grey),
                              borderRadius: BorderRadius.circular(6),
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(f.label, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
                  ]),
                ),
              ),
          ],
        ),
      );

  // ---------- 2: part (audio + foto/video) ----------
  Widget _partsStep() => Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 0),
          child: Row(children: [
            const Icon(Icons.photo_size_select_large, size: 18),
            const SizedBox(width: 8),
            const Text('Ukuran gambar', style: grey),
            Expanded(child: Slider(value: thumbSize, min: 60, max: 320, onChanged: (v) => setState(() => thumbSize = v))),
          ]),
        ),
        Expanded(
          child: ListView(padding: const EdgeInsets.all(12), children: [
            for (var pi = 0; pi < parts.length; pi++) _partCard(pi),
            OutlinedButton.icon(
              onPressed: () => setState(() => parts.add(Part())),
              icon: const Icon(Icons.add),
              label: Text('Tambah Part ${parts.length + 1}'),
            ),
            const SizedBox(height: 12),
          ]),
        ),
      ]);

  Widget _partCard(int pi) {
    final part = parts[pi];
    final leads = <int, int>{}; // indeks media -> nomor slide
    var i = 0, fi = 0;
    while (i < part.items.length) {
      leads[i] = fi++;
      i += max(1, part.items[i].multi);
    }
    return Card(
      key: part.key,
      margin: const EdgeInsets.only(bottom: 14),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Text('Part ${pi + 1}', style: const TextStyle(color: orange, fontWeight: FontWeight.bold, fontSize: 20)),
            const Spacer(),
            IconButton(
              tooltip: 'Naikkan part',
              onPressed: pi > 0
                  ? () => setState(() {
                        parts.insert(pi - 1, parts.removeAt(pi));
                      })
                  : null,
              icon: const Icon(Icons.arrow_upward),
            ),
            IconButton(
              tooltip: 'Turunkan part',
              onPressed: pi < parts.length - 1
                  ? () => setState(() {
                        parts.insert(pi + 1, parts.removeAt(pi));
                      })
                  : null,
              icon: const Icon(Icons.arrow_downward),
            ),
            IconButton(
              tooltip: 'Hapus part',
              onPressed: parts.length > 1 ? () => setState(() => parts.removeAt(pi)) : null,
              icon: const Icon(Icons.delete_outline),
            ),
          ]),
          const SizedBox(height: 4),
          _audioBlock(part),
          const SizedBox(height: 10),
          if (part.items.isNotEmpty)
            ReorderableListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: part.items.length,
              onReorder: (a, b) => setState(() {
                if (b > a) b--;
                part.items.insert(b, part.items.removeAt(a));
              }),
              itemBuilder: (c, idx) => Card(
                key: part.items[idx].key,
                color: Theme.of(context).colorScheme.surfaceContainerHighest.withOpacity(0.4),
                child: _mediaTile(part, idx, part.items[idx], leads[idx]),
              ),
            ),
          OutlinedButton.icon(
            onPressed: totalItems >= kMaxItems ? null : () => addMedia(part),
            icon: const Icon(Icons.add_photo_alternate_outlined),
            label: Text('Load foto / video (${totalItems}/$kMaxItems)'),
          ),
          if (part.items.isNotEmpty) _partTiming(part),
        ]),
      ),
    );
  }

  Widget _audioBlock(Part part) {
    final s = part.sound;
    if (s == null) {
      return OutlinedButton.icon(
        onPressed: () => addSound(part),
        icon: const Icon(Icons.music_note),
        label: const Text('Load audio'),
      );
    }
    final k = part.hashCode;
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        border: Border.all(color: orange.withOpacity(0.6)),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(children: [
        Row(children: [
          const Icon(Icons.music_note, color: orange),
          const SizedBox(width: 8),
          Expanded(child: Text(s.name, maxLines: 1, overflow: TextOverflow.ellipsis)),
          Text(fmtTime(s.len), style: grey),
          IconButton(
            tooltip: 'Ganti audio',
            onPressed: () => addSound(part),
            icon: const Icon(Icons.swap_horiz),
          ),
          IconButton(
            tooltip: 'Hapus audio',
            onPressed: () => setState(() => part.sound = null),
            icon: const Icon(Icons.close),
          ),
        ]),
        const SizedBox(height: 6),
        Row(children: [
          Expanded(child: _timeField('Pakai dari', s.start, (v) => s.start = max(0.0, v), 'as$k')),
          const SizedBox(width: 8),
          Expanded(child: _timeField('Sampai', s.stop, (v) => s.stop = max(s.start + 0.5, min(v, s.len)), 'ae$k')),
        ]),
        Row(children: [
          Icon(s.volume == 0 ? Icons.volume_off : Icons.volume_up, size: 20),
          Expanded(
            child: Slider(
              value: s.volume,
              min: 0,
              max: 2,
              divisions: 40,
              label: '${(s.volume * 100).round()}%',
              onChanged: (v) => setState(() => s.volume = v),
            ),
          ),
          SizedBox(width: 48, child: Text('${(s.volume * 100).round()}%', style: grey)),
        ]),
      ]),
    );
  }

  Widget _timeField(String label, double v, ValueChanged<double> on, String k) => TextFormField(
        key: ValueKey('$k$_rev'),
        initialValue: fmtTime(v),
        keyboardType: TextInputType.datetime,
        decoration: InputDecoration(labelText: label, border: const OutlineInputBorder(), isDense: true),
        onChanged: (t) => setState(() => on(parseTime(t, v))),
      );

  Widget _partTiming(Part part) {
    final plan = part.plan(pause);
    final fr = part.frames;
    final k = part.hashCode;
    return Padding(
      padding: const EdgeInsets.only(top: 10),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(
          '${part.items.length} media • ${fr.length} slide • durasi part ${fmtTime(plan.total)}'
          '${part.sound != null ? ' (mengikuti audio)' : ''}',
          style: const TextStyle(fontWeight: FontWeight.w600),
        ),
        if (part.sound == null && !part.sync) ...[
          const SizedBox(height: 8),
          _timeField('Lama tiap foto/video (m:ss)', part.manualDur, (v) => part.manualDur = max(0.5, v), 'md$k'),
        ],
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('Atur waktu mulai manual per media'),
          subtitle: Text(
            part.sound != null
                ? 'Samakan momen gambar dengan suara: isi menit & detik mulai tiap foto/video. Kecepatan video menyesuaikan.'
                : 'Isi menit & detik mulai tiap foto/video. Kecepatan video menyesuaikan.',
            style: grey,
          ),
          value: part.sync,
          onChanged: (v) => setState(() {
            part.sync = v;
            if (v) {
              part.end = null;
              part.fillStarts(pause);
              _rev++;
            }
          }),
        ),
        if (part.sync) ...[
          _timeField('Akhir part (m:ss)', part.end ?? part.defaultEnd(pause), (v) => part.end = v, 'pe$k'),
          Align(
            alignment: Alignment.centerLeft,
            child: TextButton.icon(
              onPressed: () => setState(() {
                part.end = null;
                part.fillStarts(pause);
                _rev++;
              }),
              icon: const Icon(Icons.refresh, size: 18),
              label: const Text('Isi ulang waktu otomatis'),
            ),
          ),
          for (var f = 0; f < fr.length; f++) ...[
            Padding(
              padding: const EdgeInsets.only(top: 10, bottom: 4),
              child: Text('Slide ${f + 1} — isi ${fr[f].length}', style: const TextStyle(color: orange, fontWeight: FontWeight.bold)),
            ),
            for (var j = 0; j < fr[f].length; j++) _syncRow(fr[f][j], plan.dur[f][j]),
          ],
        ] else if (part.sound != null)
          const Padding(
            padding: EdgeInsets.only(top: 4),
            child: Text('Media dibagi rata sepanjang audio part ini.', style: grey),
          ),
      ]),
    );
  }

  Widget _startField(Media m) => SizedBox(
        width: 110,
        child: TextFormField(
          key: ValueKey('st${m.key}$_rev'),
          initialValue: fmtTimeP(m.startAt ?? 0),
          keyboardType: TextInputType.datetime,
          decoration: const InputDecoration(labelText: 'Mulai (m:ss)', border: OutlineInputBorder(), isDense: true),
          onChanged: (t) => setState(() => m.startAt = parseTime(t, m.startAt ?? 0)),
        ),
      );

  Widget _syncRow(Media m, double du) {
    final spd = (m.isVideo && m.dur > 0) ? m.dur / du : 0.0;
    final bad = spd > 4 || (spd > 0 && spd < 0.25);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(6),
          child: Container(
            width: 64,
            height: 64,
            color: Colors.black26,
            child: m.isVideo ? const Icon(Icons.movie) : Image.file(File(m.path), fit: BoxFit.contain, cacheWidth: 300),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(m.path.split(RegExp(r'[\\/]')).last, maxLines: 1, overflow: TextOverflow.ellipsis),
            Text(
              'tampil ${du.toStringAsFixed(1)} dtk${spd > 0 ? ' • video ${spd.toStringAsFixed(2)}x' : ''}',
              style: TextStyle(color: bad ? Colors.redAccent : const Color(0xFF8D8D8D), fontSize: 12),
            ),
          ]),
        ),
        const SizedBox(width: 8),
        _startField(m),
      ]),
    );
  }

  // Ketuk gambar di daftar untuk melihatnya besar (bisa dizoom).
  void _showBig(Media m) {
    if (m.isVideo) return;
    showDialog(
      context: context,
      builder: (c) => Dialog(
        insetPadding: const EdgeInsets.all(16),
        child: GestureDetector(
          onTap: () => Navigator.pop(c),
          child: InteractiveViewer(child: Image.file(File(m.path), fit: BoxFit.contain)),
        ),
      ),
    );
  }

  Widget _layoutThumb(List<Media> g, int fi) {
    final f = fmt!;
    final panels = comicLayout(f, g, effVariant(g, fi), bg);
    return SizedBox(
      height: 56,
      child: AspectRatio(
        aspectRatio: f.w / f.h,
        child: CustomPaint(painter: LayoutThumbPainter(f.w.toDouble(), f.h.toDouble(), panels, orange)),
      ),
    );
  }

  Widget _mediaTile(Part part, int idx, Media m, int? fi) => Padding(
        padding: const EdgeInsets.all(10),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('${idx + 1}', style: const TextStyle(color: orange, fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(width: 10),
          GestureDetector(
            onTap: () => _showBig(m),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Container(
                width: thumbSize,
                height: thumbSize,
                color: Colors.black26,
                child: m.isVideo
                    ? const Center(child: Icon(Icons.movie, size: 40))
                    : Image.file(File(m.path), fit: BoxFit.contain, cacheWidth: 700),
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(m.path.split(RegExp(r'[\\/]')).last, maxLines: 1, overflow: TextOverflow.ellipsis),
              if (fi == null)
                const Text('Ikut frame multi di atasnya', style: grey)
              else ...[
                Wrap(spacing: 6, children: [
                  for (final n in const [1, 2, 3, 4, 5, 6, 8])
                    ChoiceChip(
                      label: Text('${n}x'),
                      selected: m.multi == n,
                      onSelected: (_) => setState(() {
                        m.multi = n;
                        m.variant = -1;
                      }),
                    ),
                ]),
                const SizedBox(height: 6),
                Row(children: [
                  _layoutThumb(part.frames[fi], fi),
                  const SizedBox(width: 8),
                  if (bg.comic)
                    TextButton.icon(
                      onPressed: () => setState(() => m.variant = effVariant(part.frames[fi], fi) + 1),
                      icon: const Icon(Icons.shuffle, size: 18),
                      label: const Text('Ganti susunan'),
                    ),
                ]),
                if (m.multi == 1)
                  Row(children: [
                    const Text('Ukuran', style: grey),
                    Expanded(child: Slider(value: m.zoom.clamp(0.5, 1.0).toDouble(), min: 0.5, max: 1, onChanged: (v) => setState(() => m.zoom = v))),
                    Text('${(m.zoom * 100).round()}%', style: grey),
                  ]),
              ],
            ]),
          ),
          IconButton(onPressed: () => setState(() => part.items.remove(m)), icon: const Icon(Icons.close)),
        ]),
      );

  Widget _thumb(Media m, {bool cover = false}) => m.isVideo
      ? Container(color: Colors.blueGrey.shade800, child: const Icon(Icons.movie))
      : Image.file(File(m.path), fit: cover ? BoxFit.cover : BoxFit.contain, cacheWidth: 400);

  // ---------- 3: latar & gaya ----------
  Widget _bgStep() {
    final f = fmt!;
    final fr = allPages;
    final pi = pv.clamp(0, fr.length - 1);
    const colors = [
      0xFFFFFFFF, 0xFFF5E9D0, 0xFF9E9E9E, 0xFF111111, 0xFFE8501F, 0xFFFFC107,
      0xFF2E7D32, 0xFF1E3A8A, 0xFF6A1B9A, 0xFFD81B60, 0xFF00897B, 0xFF5D4037,
    ];
    return ListView(padding: const EdgeInsets.all(16), children: [
      Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxHeight: 380),
          child: AspectRatio(aspectRatio: f.w / f.h, child: _preview(fr[pi].$1, fr[pi].$2)),
        ),
      ),
      Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        IconButton(onPressed: pi > 0 ? () => setState(() => pv = pi - 1) : null, icon: const Icon(Icons.chevron_left)),
        Text('Part ${fr[pi].$3 + 1} • slide ${fr[pi].$2 + 1}  (${pi + 1}/${fr.length})', style: grey),
        IconButton(onPressed: pi < fr.length - 1 ? () => setState(() => pv = pi + 1) : null, icon: const Icon(Icons.chevron_right)),
      ]),
      const SizedBox(height: 8),
      const Text('Gaya frame', style: grey),
      const SizedBox(height: 8),
      SegmentedButton<bool>(
        segments: const [
          ButtonSegment(value: true, label: Text('Komik (miring)')),
          ButtonSegment(value: false, label: Text('Kotak rapi')),
        ],
        selected: {bg.comic},
        onSelectionChanged: (v) => setState(() => bg.comic = v.first),
      ),
      SwitchListTile(
        contentPadding: EdgeInsets.zero,
        title: const Text('Sesuaikan frame dengan bentuk foto'),
        subtitle: const Text('Ukuran & susunan frame dihitung otomatis agar foto hampir tidak terpotong', style: grey),
        value: bg.fitLayout,
        onChanged: (v) => setState(() => bg.fitLayout = v),
      ),
      const SizedBox(height: 8),
      const Text('Latar halaman', style: grey),
      const SizedBox(height: 8),
      Wrap(spacing: 10, runSpacing: 10, children: [
        for (final c in colors)
          GestureDetector(
            onTap: () => setState(() {
              bg.color = c;
              bg.image = null;
              bgImg = null;
            }),
            child: Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: Color(c),
                shape: BoxShape.circle,
                border: Border.all(width: 3, color: bg.image == null && bg.color == c ? orange : Colors.grey.shade700),
              ),
            ),
          ),
      ]),
      const SizedBox(height: 10),
      TextField(
        decoration: const InputDecoration(
          labelText: 'Warna sendiri (hex 6 digit, mis. FF8800) lalu Enter',
          isDense: true,
          border: OutlineInputBorder(),
        ),
        onSubmitted: (t) {
          final s = t.replaceAll('#', '').trim();
          final v = int.tryParse(s, radix: 16);
          if (v != null && s.length == 6) {
            setState(() {
              bg.color = 0xFF000000 | v;
              bg.image = null;
              bgImg = null;
            });
          }
        },
      ),
      const SizedBox(height: 10),
      Row(children: [
        Expanded(
          child: OutlinedButton.icon(
            onPressed: pickBg,
            icon: const Icon(Icons.image),
            label: const Text('Muat latar dari penyimpanan'),
          ),
        ),
        if (bg.image != null) ...[
          const SizedBox(width: 8),
          IconButton(
            tooltip: 'Hapus gambar latar',
            onPressed: () => setState(() {
              bg.image = null;
              bgImg = null;
            }),
            icon: const Icon(Icons.delete_outline),
          ),
        ],
      ]),
      if (bg.image != null)
        Padding(
          padding: const EdgeInsets.only(top: 4),
          child: Text(bg.image!.split(RegExp(r'[\\/]')).last, style: grey, maxLines: 1, overflow: TextOverflow.ellipsis),
        ),
      const SizedBox(height: 12),
      Text('Jarak antar frame: ${(bg.gap * 100).toStringAsFixed(1)}%'),
      Slider(value: bg.gap, min: 0.004, max: 0.04, onChanged: (v) => setState(() => bg.gap = v)),
      Text(bg.border <= 0 ? 'Garis frame: tanpa garis' : 'Tebal garis frame: ${(bg.border * 100).toStringAsFixed(1)}%'),
      Slider(value: bg.border, min: 0, max: 0.015, onChanged: (v) => setState(() => bg.border = v)),
      SegmentedButton<bool>(
        segments: const [
          ButtonSegment(value: false, label: Text('Garis hitam')),
          ButtonSegment(value: true, label: Text('Garis putih')),
        ],
        selected: {bg.borderWhite},
        onSelectionChanged: (v) => setState(() => bg.borderWhite = v.first),
      ),
      if (bg.image != null) ...[
        const SizedBox(height: 8),
        Text('Redupkan latar gambar: ${(bg.dim * 100).round()}%'),
        Slider(value: bg.dim, min: 0, max: 0.7, onChanged: (v) => setState(() => bg.dim = v)),
      ],
      const SizedBox(height: 12),
      const Text('Cara menampilkan foto/video di dalam frame', style: grey),
      const SizedBox(height: 8),
      SegmentedButton<int>(
        segments: const [
          ButtonSegment(value: 2, label: Text('Penuh')),
          ButtonSegment(value: 0, label: Text('Utuh')),
          ButtonSegment(value: 1, label: Text('Auto')),
          ButtonSegment(value: 3, label: Text('Utuh+blur')),
        ],
        selected: {opts.mode},
        onSelectionChanged: (v) => setState(() => opts.mode = v.first),
      ),
      const SizedBox(height: 8),
      const Text('Penuh = foto mengisi frame (dengan opsi "Sesuaikan frame" aktif, hampir tidak ada yang terpotong). Utuh = lengkap dengan bar hitam. Auto = penuh bila bentuknya mirip, selain itu utuh. Utuh+blur = lengkap, sisa ruang diisi gambar buram.', style: grey),
    ]);
  }

  Widget _panelThumb(Media m, Panel p, double s) {
    if (useBlur(opts)) {
      final b = p.box;
      final r = p.fit(m.w > 0 && m.h > 0 ? m.w / m.h : b.width / b.height);
      return Positioned(
        left: b.left * s,
        top: b.top * s,
        width: b.width * s,
        height: b.height * s,
        child: ClipRect(
          child: Stack(fit: StackFit.expand, children: [
            ImageFiltered(
              imageFilter: ui.ImageFilter.blur(sigmaX: 10, sigmaY: 10),
              child: _thumb(m, cover: true),
            ),
            Positioned(
              left: (r.left - b.left) * s,
              top: (r.top - b.top) * s,
              width: r.width * s,
              height: r.height * s,
              child: _thumb(m, cover: false),
            ),
          ]),
        ),
      );
    }
    if (useCover(opts, m, p)) {
      final b = p.box;
      return Positioned(
        left: b.left * s,
        top: b.top * s,
        width: b.width * s,
        height: b.height * s,
        child: ClipRect(child: _thumb(m, cover: true)),
      );
    }
    final r = p.fit(m.w > 0 && m.h > 0 ? m.w / m.h : p.box.width / p.box.height);
    return Positioned(left: r.left * s, top: r.top * s, width: r.width * s, height: r.height * s, child: _thumb(m, cover: false));
  }

  Widget _preview(List<Media> g, int fi) {
    final f = fmt!;
    final panels = comicLayout(f, g, effVariant(g, fi), bg);
    return LayoutBuilder(builder: (c, box) {
      final s = box.maxWidth / f.w;
      return ClipRect(
        child: Stack(children: [
          Positioned.fill(
            child: CustomPaint(painter: GutterPainter(f.w.toDouble(), f.h.toDouble(), const <Panel>[], bg, bgImg)),
          ),
          for (var k = 0; k < g.length && k < panels.length; k++) _panelThumb(g[k], panels[k], s),
          Positioned.fill(
            child: CustomPaint(painter: GutterPainter(f.w.toDouble(), f.h.toDouble(), panels, bg, bgImg)),
          ),
        ]),
      );
    });
  }

  // ---------- 4: ekspor ----------
  Widget _exportStep() {
    final active = parts.where((p) => p.items.isNotEmpty).toList();
    var total = 0.0;
    for (final p in active) {
      total += p.dur(pause);
    }
    final slides = active.fold<int>(0, (a, p) => a + p.frames.length);
    return ListView(padding: const EdgeInsets.all(16), children: [
      Card(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Hasil video', style: TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            SegmentedButton<int>(
              segments: const [
                ButtonSegment(value: 0, label: Text('Gabung semua part')),
                ButtonSegment(value: 1, label: Text('Per part')),
                ButtonSegment(value: 2, label: Text('Per slide')),
              ],
              selected: {outMode},
              onSelectionChanged: (v) => setState(() => outMode = v.first),
            ),
            const SizedBox(height: 8),
            Text(
              switch (outMode) {
                0 => 'Satu video panjang: Part 1, Part 2, Part 3, … berurutan.',
                1 => '${active.length} file video terpisah, satu per part (lengkap dengan audionya).',
                _ => '$slides file video terpisah, satu per slide (mis. slide isi 2, isi 3, isi 4 media), audio dipotong sesuai waktunya.',
              },
              style: grey,
            ),
          ]),
        ),
      ),
      Card(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Jeda antar slide: ${pause.round()} detik'),
            Slider(
              value: pause,
              min: 0,
              max: 10,
              divisions: 10,
              label: '${pause.round()} dtk',
              onChanged: (v) => setState(() => pause = v),
            ),
            const Text('Hasil akhir tiap slide ditahan selama jeda ini sebelum pindah ke slide berikutnya (termasuk dalam durasi audio part).', style: grey),
          ]),
        ),
      ),
      Card(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Kualitas hasil'),
            const SizedBox(height: 8),
            SegmentedButton<int>(
              segments: const [
                ButtonSegment(value: 0, label: Text('Cepat')),
                ButtonSegment(value: 1, label: Text('Standar')),
                ButtonSegment(value: 2, label: Text('Tinggi')),
              ],
              selected: {opts.quality},
              onSelectionChanged: (v) => setState(() => opts.quality = v.first),
            ),
            const SizedBox(height: 8),
            const Text('Cepat = proses tercepat, resolusi lebih kecil. Tinggi = paling tajam tapi paling lama.', style: grey),
          ]),
        ),
      ),
      Card(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Ringkasan', style: TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            for (var i = 0; i < parts.length; i++)
              if (parts[i].items.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 2),
                  child: Text(
                    'Part ${i + 1}: ${parts[i].items.length} media, ${parts[i].frames.length} slide, ${fmtTime(parts[i].dur(pause))}'
                    '${parts[i].sound != null ? ' • ${parts[i].sound!.name}' : ' • tanpa audio'}',
                    style: grey,
                  ),
                ),
            const SizedBox(height: 6),
            Text('Total: ${fmtTime(total)}', style: const TextStyle(fontWeight: FontWeight.w600)),
          ]),
        ),
      ),
    ]);
  }
}
