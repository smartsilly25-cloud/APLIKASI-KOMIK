import 'dart:math';
import 'dart:ui';
import 'models.dart';

// ===================== TATA LETAK KOMIK =====================
//
// Halaman dipotong berulang dengan garis (boleh miring) menjadi panel-panel
// poligon, seperti halaman komik. Tiap susunan ditulis sebagai pohon potongan:
//   _h(rasio, miring, atas, bawah)  -> potong mendatar
//   _v(rasio, miring, kiri, kanan)  -> potong tegak
// "miring" dalam derajat. Urutan daun = urutan baca (kiri-atas dulu).

abstract class Tn {
  const Tn();
}

class Leaf extends Tn {
  const Leaf();
}

class Cut extends Tn {
  final bool vert;
  final double ratio, skew;
  final Tn a, b;
  const Cut(this.vert, this.ratio, this.skew, this.a, this.b);
}

const Tn _p = Leaf();
Tn _h(double r, double s, Tn a, Tn b) => Cut(false, r, s, a, b);
Tn _v(double r, double s, Tn a, Tn b) => Cut(true, r, s, a, b);

/// Putar 90 derajat (tegak <-> mendatar) untuk kanvas lebar.
Tn _tr(Tn t) => t is Cut ? Cut(!t.vert, t.ratio, t.skew, _tr(t.a), _tr(t.b)) : t;

final Map<int, List<Tn>> _templates = {
  2: [
    _h(.5, 4, _p, _p),
    _v(.5, 8, _p, _p),
    _h(.42, -5, _p, _p),
    _v(.58, -9, _p, _p),
  ],
  3: [
    _h(.5, 4, _p, _v(.5, -8, _p, _p)),
    _v(.5, 6, _p, _h(.5, -5, _p, _p)),
    _h(.34, 4, _p, _h(.5, -4, _p, _p)),
    _h(.55, -4, _v(.5, 8, _p, _p), _p),
  ],
  5: [
    _h(.5, 3, _v(.5, 6, _p, _p), _v(.33, -6, _p, _v(.5, 6, _p, _p))),
    _v(.5, 5, _h(.5, -4, _p, _p), _h(.33, 4, _p, _h(.5, -4, _p, _p))),
    _h(.4, -3, _p, _h(.5, 3, _v(.5, 6, _p, _p), _v(.5, -6, _p, _p))),
  ],
  4: [
    _h(.5, 0, _v(.45, 8, _p, _p), _v(.55, -8, _p, _p)),
    _v(.5, 6, _h(.5, -5, _p, _p), _h(.5, 5, _p, _p)),
    _h(.42, 4, _p, _v(.33, 8, _p, _v(.5, -8, _p, _p))),
    _h(.5, -3, _v(.6, -8, _p, _p), _v(.4, 8, _p, _p)),
  ],
  6: [
    _h(.33, 3, _v(.5, 8, _p, _p), _h(.5, -3, _v(.4, -8, _p, _p), _v(.6, 8, _p, _p))),
    _v(.5, 5, _h(.33, 4, _p, _h(.5, -4, _p, _p)), _h(.33, -4, _p, _h(.5, 4, _p, _p))),
    _h(.5, 0, _v(.33, 5, _p, _v(.5, -4, _p, _p)), _v(.4, -5, _p, _v(.5, 4, _p, _p))),
  ],
  8: [
    _h(.5, 0, _v(.5, 5, _v(.5, -5, _p, _p), _v(.5, 5, _p, _p)), _v(.5, -5, _v(.5, 5, _p, _p), _v(.5, -5, _p, _p))),
    _v(.5, 4, _h(.5, -3, _h(.5, 3, _p, _p), _h(.5, -3, _p, _p)), _h(.5, 3, _h(.5, -3, _p, _p), _h(.5, 3, _p, _p))),
    _h(.33, 3, _v(.5, 6, _p, _p),
        _h(.5, -3, _v(.38, -4, _p, _v(.5, 5, _p, _p)), _v(.5, 5, _p, _v(.38, -4, _p, _p)))),
  ],
};

int templateCount(int n) => _templates[n]?.length ?? 3;

/// Susunan kotak rapi (gaya lama): baris x kolom.
Tn _gridTree(int cols, int rows) {
  Tn row(int c) => c <= 1 ? _p : _v(1 / c, 0, _p, row(c - 1));
  Tn col(int r) => r <= 1 ? row(cols) : _h(1 / r, 0, row(cols), col(r - 1));
  return col(rows);
}

// ===================== PANEL =====================

class IRect {
  final int l, t, w, h;
  const IRect(this.l, this.t, this.w, this.h);
}

class Panel {
  final List<Offset> poly;
  late final Rect box = _bbox(poly);
  late final Offset center = _centroid(poly, box);
  late final bool isRect = _isRect(poly, box);
  Panel(this.poly);

  /// Kotak bulat bertepi genap yang menutup seluruh panel (untuk dipotong/di-mask).
  IRect get cell {
    final l = box.left.floor(), t = box.top.floor();
    var w = box.right.ceil() - l, h = box.bottom.ceil() - t;
    if (w.isOdd) w++;
    if (h.isOdd) h++;
    return IRect(l, t, w, h);
  }

  /// Persegi panjang terbesar dengan rasio [aspect] yang muat utuh di dalam panel.
  Rect fit(double aspect) {
    final maxW = min(box.width, box.height * aspect);
    bool ok(double wd) {
      final hd = wd / aspect;
      for (final sx in const [-1.0, 1.0]) {
        for (final sy in const [-1.0, 1.0]) {
          if (!_inside(poly, Offset(center.dx + sx * wd / 2, center.dy + sy * hd / 2))) return false;
        }
      }
      return true;
    }

    var wd = maxW;
    if (!ok(wd)) {
      var lo = 0.0, hi = maxW;
      for (var i = 0; i < 30; i++) {
        final mid = (lo + hi) / 2;
        if (ok(mid)) {
          lo = mid;
        } else {
          hi = mid;
        }
      }
      wd = lo;
    }
    return Rect.fromCenter(center: center, width: wd, height: wd / aspect);
  }
}

Rect _bbox(List<Offset> p) {
  var x0 = p.first.dx, y0 = p.first.dy, x1 = x0, y1 = y0;
  for (final q in p) {
    x0 = min(x0, q.dx);
    y0 = min(y0, q.dy);
    x1 = max(x1, q.dx);
    y1 = max(y1, q.dy);
  }
  return Rect.fromLTRB(x0, y0, x1, y1);
}

Offset _centroid(List<Offset> p, Rect box) {
  var a = 0.0, cx = 0.0, cy = 0.0;
  for (var i = 0; i < p.length; i++) {
    final q0 = p[i], q1 = p[(i + 1) % p.length];
    final cr = q0.dx * q1.dy - q1.dx * q0.dy;
    a += cr;
    cx += (q0.dx + q1.dx) * cr;
    cy += (q0.dy + q1.dy) * cr;
  }
  a /= 2;
  if (a.abs() < 1e-6) return box.center;
  return Offset(cx / (6 * a), cy / (6 * a));
}

bool _isRect(List<Offset> p, Rect b) {
  if (p.length != 4) return false;
  bool near(double v, double a, double c) => (v - a).abs() < 0.5 || (v - c).abs() < 0.5;
  for (final q in p) {
    if (!near(q.dx, b.left, b.right) || !near(q.dy, b.top, b.bottom)) return false;
  }
  return true;
}

bool _inside(List<Offset> poly, Offset q) {
  bool? pos;
  for (var i = 0; i < poly.length; i++) {
    final a = poly[i], b = poly[(i + 1) % poly.length];
    final c = (b.dx - a.dx) * (q.dy - a.dy) - (b.dy - a.dy) * (q.dx - a.dx);
    if (c.abs() < 1e-9) continue;
    if (pos == null) {
      pos = c > 0;
    } else if (pos != (c > 0)) {
      return false;
    }
  }
  return true;
}

/// Sutherland-Hodgman: simpan titik dengan (q-p).n >= off.
List<Offset> _clip(List<Offset> poly, Offset p, Offset n, double off) {
  final out = <Offset>[];
  for (var i = 0; i < poly.length; i++) {
    final a = poly[i], b = poly[(i + 1) % poly.length];
    final fa = (a.dx - p.dx) * n.dx + (a.dy - p.dy) * n.dy - off;
    final fb = (b.dx - p.dx) * n.dx + (b.dy - p.dy) * n.dy - off;
    if (fa >= 0) out.add(a);
    if ((fa >= 0) != (fb >= 0)) {
      final t = fa / (fa - fb);
      out.add(Offset(a.dx + (b.dx - a.dx) * t, a.dy + (b.dy - a.dy) * t));
    }
  }
  return out;
}

void _split(List<Offset> poly, Tn t, double gap, List<List<Offset>> out) {
  if (t is! Cut) {
    out.add(poly);
    return;
  }
  final b = _bbox(poly);
  final th = t.skew * pi / 180;
  final Offset p, n;
  if (t.vert) {
    p = Offset(b.left + t.ratio * b.width, b.center.dy);
    n = Offset(cos(th), -sin(th));
  } else {
    p = Offset(b.center.dx, b.top + t.ratio * b.height);
    n = Offset(-sin(th), cos(th));
  }
  _split(_clip(poly, p, Offset(-n.dx, -n.dy), gap / 2), t.a, gap, out);
  _split(_clip(poly, p, n, gap / 2), t.b, gap, out);
}

/// Pilihan susunan: nomor yang dipakai halaman ke-[frameIdx] bila tidak dipilih manual.
int effVariant(List<Media> g, int frameIdx) {
  final m = g.first;
  if (m.variant >= 0) return m.variant;
  return m.multi == 1 ? 0 : frameIdx;
}

double _asp(Media m) => (m.w > 0 && m.h > 0) ? m.w / m.h : (m.isVideo ? 16 / 9 : 1.0);

/// Rata-rata bagian gambar yang terpotong bila memenuhi panel (0 = pas).
double _loss(List<Panel> ps, List<double> asps) {
  var s = 0.0;
  final n = min(ps.length, asps.length);
  for (var k = 0; k < n; k++) {
    final c = ps[k].box.width / ps[k].box.height, a = asps[k];
    s += 1 - min(a, c) / max(a, c);
  }
  return n == 0 ? 0 : s / n;
}

void _collect(Tn t, List<double> out) {
  if (t is Cut) {
    out.add(t.ratio);
    _collect(t.a, out);
    _collect(t.b, out);
  }
}

Tn _apply(Tn t, List<double> rs, List<int> i) {
  if (t is! Cut) return t;
  final r = rs[i[0]++];
  final a = _apply(t.a, rs, i);
  final b = _apply(t.b, rs, i);
  return Cut(t.vert, r, t.skew, a, b);
}

List<Panel> _panelsOf(Tn t, List<Offset> region, double gap) {
  final out = <List<Offset>>[];
  _split(region, t, gap, out);
  return [for (final p in out) if (p.length >= 3) Panel(p)];
}

/// Geser rasio potongan supaya bentuk tiap panel mendekati bentuk fotonya.
Tn _optimize(Tn t, List<Offset> region, double gap, List<double> asps, void Function(double) onLoss) {
  final rs = <double>[];
  _collect(t, rs);
  double score() => _loss(_panelsOf(_apply(t, rs, [0]), region, gap), asps);
  var best = score();
  for (var pass = 0; pass < 3; pass++) {
    for (var i = 0; i < rs.length; i++) {
      var bestR = rs[i];
      for (var r = 0.28; r <= 0.7201; r += 0.04) {
        rs[i] = r;
        final s = score();
        if (s < best - 1e-9) {
          best = s;
          bestR = r;
        }
      }
      rs[i] = bestR;
    }
  }
  onLoss(best);
  return _apply(t, rs, [0]);
}

final Map<String, List<Panel>> _cache = {};

/// Panel-panel untuk satu halaman (urutan baca). Jumlah panel = jumlah "multi".
List<Panel> comicLayout(Fmt f, List<Media> g, int variant, Bg st) {
  final n = g.first.multi < 1 ? 1 : g.first.multi;
  final asps = [for (final m in g) _asp(m)];
  final key = '${f.w}x${f.h}|$n|$variant|${g.first.variant}|${st.comic}|${st.fitLayout}|'
      '${st.gap.toStringAsFixed(4)}|${g.first.zoom.toStringAsFixed(2)}|'
      '${asps.map((a) => a.toStringAsFixed(3)).join(",")}';
  final hit = _cache[key];
  if (hit != null) return hit;
  if (_cache.length > 300) _cache.clear();
  return _cache[key] = _layout(f, g, n, variant, st, asps);
}

List<Panel> _layout(Fmt f, List<Media> g, int n, int variant, Bg st, List<double> asps) {
  final w = f.w.toDouble(), h = f.h.toDouble();
  final sh = min(w, h);
  final gap = sh * st.gap;
  final m = max(gap * 1.5, sh * 0.025);

  if (n == 1) {
    final z = g.first.zoom.clamp(0.3, 1.0).toDouble();
    final cx = w / 2, cy = h / 2;
    var hw = (w - 2 * m) / 2, hh = (h - 2 * m) / 2;
    if (st.fitLayout) {
      // frame tunggal mengikuti bentuk foto, jadi tidak terpotong
      final a = asps.first;
      if (a > hw / hh) {
        hh = hw / a;
      } else {
        hw = hh * a;
      }
    }
    hw *= z;
    hh *= z;
    final sk = sh * 0.035;
    final vs = st.comic ? variant % 3 : 0;
    final List<Offset> pts;
    if (vs == 1) {
      pts = [Offset(cx - hw + sk, cy - hh), Offset(cx + hw, cy - hh), Offset(cx + hw - sk, cy + hh), Offset(cx - hw, cy + hh)];
    } else if (vs == 2) {
      pts = [Offset(cx - hw, cy - hh), Offset(cx + hw, cy - hh + sk), Offset(cx + hw, cy + hh), Offset(cx - hw, cy + hh - sk)];
    } else {
      pts = [Offset(cx - hw, cy - hh), Offset(cx + hw, cy - hh), Offset(cx + hw, cy + hh), Offset(cx - hw, cy + hh)];
    }
    return [Panel(pts)];
  }

  final region = [Offset(m, m), Offset(w - m, m), Offset(w - m, h - m), Offset(m, h - m)];
  if (!st.comic) {
    final grid = bestGrid(f, g);
    return _panelsOf(_gridTree(grid[0], grid[1]), region, gap);
  }
  final lst = _templates[n] ?? _templates[2]!;
  Tn prep(Tn t) => w > h ? _tr(t) : t;

  if (!st.fitLayout) return _panelsOf(prep(lst[variant % lst.length]), region, gap);

  // Susunan manual (tombol "Ganti susunan"): pakai pola itu, rasio disesuaikan.
  if (g.first.variant >= 0) {
    final t = _optimize(prep(lst[variant % lst.length]), region, gap, asps, (_) {});
    return _panelsOf(t, region, gap);
  }
  // Otomatis: coba semua pola, ambil yang paling sedikit memotong foto;
  // pola yang selisihnya kecil digilir antar halaman supaya bervariasi.
  final trees = <Tn>[];
  final losses = <double>[];
  for (final tpl in lst) {
    var l = 0.0;
    trees.add(_optimize(prep(tpl), region, gap, asps, (v) => l = v));
    losses.add(l);
  }
  final best = losses.reduce(min);
  final ok = [for (var i = 0; i < trees.length; i++) if (losses[i] <= best + 0.03) i];
  return _panelsOf(trees[ok[variant % ok.length]], region, gap);
}

/// Isi penuh panel (dipotong) atau tampil utuh di dalam panel.
/// Otomatis: penuh bila bentuk media mirip bentuk panel (potongan <= 30%).
bool useCover(Opts o, Media m, Panel p) {
  if (o.mode == 0) return false;
  if (o.mode >= 2) return true; // 2 = penuh, 3 = utuh + latar blur
  if (m.w <= 0 || m.h <= 0) return false;
  final a = m.w / m.h, c = p.box.width / p.box.height;
  return 1 - min(a, c) / max(a, c) <= 0.3;
}

/// Mode 3: gambar tampil utuh, sisa ruang panel diisi salinan gambar yang diburamkan.
bool useBlur(Opts o) => o.mode == 3;
